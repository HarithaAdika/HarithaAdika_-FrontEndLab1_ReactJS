import axios from 'axios';
import IDataList from '../model/IDataList';

const getDataFromServer = () => {
    return axios.get<IDataList[]>(`https://localhost:3001/items`)
        .then(response => response.data)
};

const pushDataFromServer = (newpurchase: Omit<IDataList, 'id'>) => {
    return axios.post<IDataList>(`https://localhost:3001/items`, newpurchase,
        {
            headers: {
                'Content-type': 'application/json'
            }
        })
        .then(response => response.data)

};

export {
    getDataFromServer,
    pushDataFromServer
}